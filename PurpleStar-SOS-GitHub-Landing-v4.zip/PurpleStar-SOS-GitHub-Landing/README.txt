PURPLESTAR SOS — GITHUB PAGES LANDING PAGE
==========================================

FILES
-----
index.html   Main one-page landing page
script.js    Matrix background, date, and launch behavior
README.txt   Setup instructions

APP FILE
--------
The ENTER THE MATRIX button looks for this file in the same folder:

PurpleStarSOS.html

Rename your current application HTML file to PurpleStarSOS.html before uploading,
or change APP_FILE at the top of script.js to the correct filename.

GITHUB PAGES SETUP
------------------
1. Create a new public GitHub repository.
2. Upload index.html, script.js, README.txt, and PurpleStarSOS.html.
3. Open the repository Settings.
4. Select Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /root folder.
7. Save.
8. GitHub will provide your public Pages address after deployment.

The PurpleStar Tarot button already links to:
https://purplestar-tarot.com

OPTIONAL CUSTOM DOMAIN
----------------------
You may later connect a subdomain such as:
sos.purplestar-tarot.com

Use GitHub Pages custom-domain instructions and update your domain DNS records.

NOTES
-----
This landing page uses no external libraries, fonts, images, or frameworks.
The star-eye logo is built entirely with CSS so the repository stays minimal.
